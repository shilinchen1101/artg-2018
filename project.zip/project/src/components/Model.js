function Model(){

	//Module internal state
	let _url;
	let _parse = d => d;
	let _dataStore;

	function exports(){}

	exports.url = function(_){

	}

	exports.parse = function(fn){

	}

	exports.fetch = function(){

	}

	exports.toJSON = function(){

	}
}

export default Model;