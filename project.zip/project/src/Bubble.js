import * as d3 from 'd3';

function Bubble(_){

  let _w;
  let _h;

  let nodes;
  let _forceX, _forceY, _forceSimulation;

  let ctx;



  function exports(deaths){

    _w = _.clientWidth;
    _h = _.clientHeight;


    nodes = deaths.map(d => {
      return{
        radius: 2,
        x: Math.random() * _w,
        y: Math.random() * _h,
        ...d
      }
    });

    console.log(nodes);
    _forceSimulation.nodes(nodes);
    //return nodes;

    const root = d3.select(_);

    let svg = root
      .selectAll('.bubbleChart')
      .data([1]);

    svg = svg.enter().append('svg')
      .attr('class','.bubbleChart')
      .merge(svg)
      .attr('width',_w)
			.attr('height',_h)
			//.style('position','absolute')
			.style('top',0)
			.style('left',0);
		//ctx = canvas.node().getContext('2d');


    const myNodes = svg.selectAll('.dots')
			.data(nodes);
		const nodesEnter = myNodes.enter()
			.append('g')
			.attr('class','dots');

		nodesEnter
      .append('circle')
      .attr('r', d => d.radius)
      .style('fill','#80B3DF');
		const bubbles = nodesEnter
			.merge(myNodes)
			.attr('transform', d => `translate(${d.x}, ${d.y})`);

    const yearData = [2015,2016,2017,2018]

    const stateData = ['AK','AL','AR','AZ','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY']

    const center = { x: _w / 2, y: _h / 2 };

    const scaleX = d3.scaleBand()
           .domain([0, 1])
           .range([_w/5, 4*_w/5]);

    const scaleY = d3.scaleBand()
          .domain([0,1])
          .range([_h/5, 4*_h/5]);

    // const scaleX = d3.scaleBand()
    //   .domain(raceData)
    //   .range([_w/6, 5*_w/6])
    // const scaleY = d3.scaleBand()
    //   .domain(['White','Hispanic','Black','Native American','Pacific Islander','Asian','Unknown race'])
    //   .range([_h/6, 5*_h/6])

      const raceCenters = {
        'White':{x:_w/4,h:_h/3},
        'Hispanic':{x:_w/2,h:_h/3},
        'Black':{x:3*_w/4,h:_h/3},
        'Native American':{x:_w/5,h:2*_h/3},
        'Pacific Islander':{x:2*_w/5,h:2*_h/3},
        'Asian':{x:3*_w/5,h:2*_h/3},
        'Unknown race':{x:4*_w/5,h:2*_h/3}
      };



      const scaleX3 = d3.scaleBand()
        .domain([0,2])
        .range([_w/6, 5*_w/6])
      const scaleY3 = d3.scaleBand()
        .domain([0,2])
        .range([_h/6, 5*_h/6])


    // const scaleY = d3.scaleBand()
    //   .domain([0, 1])
    //   .range([_w/6, 5*_w/6])
    const raceButton = d3.select('#btn1')
      .on('click', function(){
        console.log(2);
        const forceX = d3.forceX().strength(0.7).x(center.x);
        const forceY = d3.forceY().strength(0.7).y(center.y);
        forceLayout(nodes, forceX, forceY);
      });


    // const forceY2 = d3.forceY().strength(forceStrength).y(function (d) {
    //     const b = Math.floor((d.year-2015)/2) //0 0 1 1
    //     return scaleY(b);
    //   }).strength(1)
    // const forceX2 = d3.forceX().strength(forceStrength).x(function(d) {
    //   //0, 1, 2, 3
    //    const a= (d.year-2015)%2 //0,1
    //     return scaleX(a);
    //   }).strength(1)

      const forceY3 = d3.forceY(function raceForceY(d) {
          if (d.race === 'White'|| d.race === 'Hispanic'|| d.race === 'Black') {
            return _h/3;
          } else if (d.race === 'Native American'|| d.race === 'Pacific Islander'|| d.race === 'Asian'|| d.race === 'Unknown race'){
            return 2*_h/3;
          } else{
            return _h/2
          }
        }).strength(0.7);
        const forceX3 = d3.forceX(function raceForceX(d) {
            if (d.race === 'White') {
              return _w/4;
            } else if (d.race === 'Hispanic'){
              return _w/2;
            }else if (d.race === 'Black'){
              return 3*_w/4;
            }else if (d.race === 'Unknown race'){
              return _w/5;
            }else if (d.race === 'Pacific Islander'){
              return 2*_w/5;
            }else if (d.race === 'Asian'){
              return 3*_w/5;
            }else if (d.race === 'Hispanic'){
              return 4*_w/5;
            }else{
              return _w/2;
            }
          }).strength(0.7);
    // const forceX3 = d3.forceX(raceForceX).strength(0.7)
    // const forceY3 = d3.forceY(raceForceY).strength(0.7)

function forceLayout(nodes,forceX,forceY){

  const forceStrength = 0.3;


 _forceSimulation
    .force("collide",d3.forceCollide(3).radius(function(d) { return d.radius + 2; }).strength(0.7) )
    .force("charge", d3.forceManyBody().strength(0.5))
    .restart()
    .alpha(0.06)
    .force('x', forceX)
    .force('y', forceY)
    .on('tick', ticked)
}




        // .force('y', d3.forceY().strength(forceStrength).y(function (d) {
        //    const b = Math.floor((d.year-2015)/2) //0 0 1 1
        //    return scaleY(b);
        //  }).strength(1))
        // .force('x', d3.forceX().strength(forceStrength).x(function(d) {
        //  //0, 1, 2, 3
        //   const a= (d.year-2015)%2 //0,1
        //    return scaleX(a);
        //  }).strength(1))

          // .velocityDecay(0.2)
          // .force('x', d3.forceX().strength(forceStrength).x(function(d) {
          //   //0, 1, 2, 3
          //   const a= (d.year-2015)%2 //0,1
          //   return scaleX(a);
          // }))
          // .force('y', d3.forceY().strength(forceStrength).y(function (d) {
          //   const b = Math.floor((d.year-2015)/2) //0 0 1 1
          //   return scaleY(b);
          // }))
          // .force("collide", d3.forceCollide().radius(function(d) { return d.radius + 1; }).iterations(2))
          // //.force("collide", d3.forceCollide().radius(function(d) { return d.radius + 0.5; }).iterations(1))
          // .force('charge', d3.forceManyBody().strength(charge))
          // .alpha(1)
          // .on('tick', ticked);


      function ticked() {
        bubbles
          .attr('transform', d => `translate(${d.x}, ${d.y})`);
      }




}

exports.forceX = function (_) {
  if(typeof_ === 'undefined') return _forceX;
  _forceX =_;
  return this;
}
exports.forcey = function (_) {
  if(typeof_ === 'undefined') return _forceY;
  _forceY =_;
  return this;
}
exports.forceSimulation = function (_) {
  if(typeof _ ==='undefined') return _forceSimulation;
  _forceSimulation =_;
  return this;
}



  return exports;
}

export default Bubble;
