export default function(d){

	const t = new Date(d.Date);


	return {
		t: t,
		year:t.getFullYear(),
		name: d.VictimsName,
		age: d.VictimsAge,
		gender: d.VictimsGender,
		race: d.VictimsRace,
		urlOfVictimes: d.URL,
		state: d.State,
		agency: d.Agency,
    description:d.Description
	}
}
