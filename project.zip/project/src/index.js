import * as d3 from 'd3';
import './style/main.css';

import parse from './parse';
import Bubble from './Bubble';
import button from './button';

var forceSimulation = d3.forceSimulation();

const bubble = Bubble( document.querySelector('#vis') )
.forceSimulation(forceSimulation);
const Button = button();

d3.csv('./data/policeviolence.csv', parse, function(err,deaths){

  bubble(deaths);
  Button(deaths);

});
