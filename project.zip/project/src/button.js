import * as d3 from 'd3';
import Bubble from './Bubble';
import './style/btn.css';

function button(_){

  function exports(deaths,_forceX,_forceY,_forceSimulation){
  //const dispatcher = dispatch('simulation');
  const oneButton = d3.select('#btn1')
      .on('click', function(){


      });
  const yearButton = d3.select('#btn2')
    .on('click', function(){


    });
  const raceButton = d3.select('#btn3')
    .on('click', function(){
      Bubble(forceX3);
      Bubble(forceY3);
    });
  const stateButton = d3.select('#btn4')
    .on('click', function(){

    });



    }



  return exports;
}

export default button;
